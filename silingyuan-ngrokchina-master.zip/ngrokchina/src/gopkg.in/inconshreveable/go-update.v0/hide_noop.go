// +build !windows

package update

func hideFile(path string) error {
	return nil
}
